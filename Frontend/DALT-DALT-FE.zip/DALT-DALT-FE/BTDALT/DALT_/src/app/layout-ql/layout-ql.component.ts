import { Component } from '@angular/core';

@Component({
  selector: 'app-layout-ql',
  templateUrl: './layout-ql.component.html',
  styleUrls: ['./layout-ql.component.scss']
})
export class LayoutQLComponent {

}
