import { Component } from '@angular/core';
import { BarkeyApiService } from 'src/app/Until/barkey-api.service';

@Component({
  selector: 'app-logging',
  templateUrl: './logging.component.html',
  styleUrls: ['./logging.component.scss']
})
export class LoggingComponent {
  
}
