import { product, DTOuser } from './../QLPage/mockdata-PQL/menu-item';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError   } from 'rxjs';
import { catchError, map } from 'rxjs/operators'; // Import operators as needed

@Injectable({
  providedIn: 'root' // Provide this service at the root level injector
})
export class BarkeyApiService {
  private accUrl = 'https://4jjl5xvc-5000.asse.devtunnels.ms/login';

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<{ message: string; username: string; status: string }> {
    return this.http.post<{ message: string; username: string; status: string }>(this.accUrl, { username, password })
      .pipe(
        catchError((error) => {
          console.error('Error logging in:', error);
          throw error;
        })
      );
  }
}