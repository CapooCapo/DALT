import { Dto } from './dto';

describe('Dto', () => {
  it('should create an instance', () => {
    expect(new Dto()).toBeTruthy();
  });
});
