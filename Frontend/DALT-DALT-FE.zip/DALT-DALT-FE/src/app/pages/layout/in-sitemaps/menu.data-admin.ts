import { MenuDataItem } from "../dto/menu-data-item";

export const moduleDataAdmin: Array<any> = [
    {
        Name: 'Sản phẩm',
        path: 'product',
        Link: 'porducts',

    },
    {
        Name: 'Khách Hàng',
        path: 'customer',
        Link: 'customer',

    },
    {
        Name: 'Khuyến mãi',
        path: '/promotion',
        Link: 'kkkkk',

    },
    {
        Name: 'đăng nhập',
        path: 'logging',
        Link: 'logging',

    }

];