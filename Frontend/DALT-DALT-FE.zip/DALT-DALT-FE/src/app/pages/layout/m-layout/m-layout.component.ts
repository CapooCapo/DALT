import { Component } from '@angular/core';

@Component({
  selector: 'app-m-layout',
  templateUrl: './m-layout.component.html',
  styleUrls: ['./m-layout.component.scss']
})
export class MLayoutComponent {
  
}
