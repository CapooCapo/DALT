import { Component } from '@angular/core';

@Component({
  selector: 'app-u-layout',
  templateUrl: './u-layout.component.html',
  styleUrls: ['./u-layout.component.scss']
})
export class ULayoutComponent {

}
