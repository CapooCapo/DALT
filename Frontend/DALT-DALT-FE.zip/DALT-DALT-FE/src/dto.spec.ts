import { DTO } from './dto';

describe('DTO', () => {
  it('should create an instance', () => {
    expect(new DTO()).toBeTruthy();
  });
});
